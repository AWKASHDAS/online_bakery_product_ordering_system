<?php
$table="tbl_vendor";
$target_path = "uploads/";
$title="Add Vendor ";
?>