<?php
$table="tbl_category";
$target_path = "uploads/";
$title="Add Category ";
?>