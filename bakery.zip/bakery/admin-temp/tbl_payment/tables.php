<?php
$table="tbl_payment";
$target_path = "uploads/";
$title="tbl_payments ";
?>