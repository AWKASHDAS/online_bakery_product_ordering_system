<?php
session_start();
include('db/connectionI.php');


$myusername=$_POST['Email']; 
$mypassword=$_POST['Password']; 


if(isset($_POST['login']))
{

if($myusername=="admin" and $mypassword="admin")
{
$_SESSION['user']="admin";
header("location:dashboard/index.php");
}
else
{
	$query = "SELECT * FROM operator_login WHERE user_name='$myusername' and password='$mypassword'"; 	 

	$data=mysqli_query($con,$query);
	$count=mysqli_num_rows($data);
	if($count==1)
	{
		
		$query1 = "SELECT * FROM operator_login WHERE user_name='$myusername' and password='$mypassword'"; 	 
		$data1=mysqli_query($con,$query1);
		$row=mysqli_fetch_array($data1);
		session_start();
		$_SESSION['type']="operator";
		$_SESSION['id']=$row['id'];
		
		header("location:dashboard/index.php");
		
	}
	else
	{
		echo "Error : ".mysqli_error($con);
		header("location:login.php?status=error");
	}
}




}

?>
 
 



