<?php
$table="tbl_cpurchase";
$target_path = "uploads/";
$title="Purchase Entry";
?>