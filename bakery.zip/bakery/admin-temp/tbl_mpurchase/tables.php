<?php
$table="tbl_mpurchase";
$target_path = "uploads/";
$title="Purchase Details ";
?>