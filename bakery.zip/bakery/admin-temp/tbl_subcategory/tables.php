<?php
$table="tbl_subcategory";
$target_path = "uploads/";
$title="Subcategory ";
?>