<?php
$table="tbl_ccart";
$target_path = "uploads/";
$title="Chat Rooms ";
?>