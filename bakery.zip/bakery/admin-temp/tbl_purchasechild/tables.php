<?php
$table="tbl_cpurchase";
$target_path = "uploads/";
$title="PURCHASE_C";
?>