<?php
$table="tbl_partner";
$target_path = "uploads/";
$title="Add Delivery Agents ";
?>