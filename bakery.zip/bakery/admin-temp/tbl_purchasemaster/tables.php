<?php
$table="tbl_purchasemaster";
$target_path = "uploads/";
$title=" Purchasemaster details";
?>