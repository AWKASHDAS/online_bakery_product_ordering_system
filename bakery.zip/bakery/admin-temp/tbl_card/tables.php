<?php
$table="tbl_card";
$target_path = "uploads/";
$title="Add Members ";
?>