<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php
include('../header.php');
//error_reporting(0);

?>

<style>
	.table{
		background-color:#fff !important;
		color: #000 !important;
	}
	</style>
<!--main content start-->
<section id="main-content">
	<section class="wrapper">
		
	<div class="col-md-12">
							<h3>Order List</h3><br>
							<?php 
								//session_start();
							?>
							
							<?php
								
								include ("../db/connectionI.php");
								
								$sel2="Select * FROM tbl_mcart";
								$res2=mysqli_query($con,$sel2);
									
								while($row2=mysqli_fetch_array($res2))
								{
									$i=1;
									$sql=mysqli_query($con,"SELECT * FROM `tbl_customer` WHERE `id`='$row2[c_id]'");
									$row3=mysqli_fetch_array($sql);
							?>
							<table class="table table-striped  table-bordered table-hover">
								<tr>
									<th>Order id</th>
									<th>Date</th>
									<th>Name</th>
									<th>Order Status </th>
									<th>Deliver</th>
								</tr>
								
								<tr>	
									<td> Bill No : #<?php echo $row2['id']?></td>
									<td><?php echo $row2['date']?></td>
									<td><?php echo $row3['cust_name']?></td>
									<td><?php echo $row2['delivery_status']?></td>
									<td><a href="deliver.php?id=<?php echo $row2['id'] ?>">Deliver</a></td>
								</tr>
									
							    <tr>
									<th>#</th>				
									<th>Items</th>
									<th>Quantity </th>
									<th>Price</th>
								</tr>
								
								  <?php
								  $sel="Select * FROM tbl_ccart WHERE om_id=$row2[id]";
								  $res=mysqli_query($con,$sel);
								  while($row=mysqli_fetch_array($res))
									{
										$sql1=mysqli_query($con,"SELECT * FROM `tbl_item` WHERE `id`='$row[item_id]'");
										$row4=mysqli_fetch_array($sql1);
												
								  ?>
									<tr>
										<td><?php echo $i;?></td>						
									    <td><?php echo $row4['item_name']?></td>
									    <td ><?php echo $row['order_qty']?></td>
									    <td><?php echo $row['price']?></td>
									</tr>
							   
								<?php
								$i++;
								}
								}
								?>
							</table>
							<br>
						</div>	
		
</section>
<?php

include("../footer.php");


?>