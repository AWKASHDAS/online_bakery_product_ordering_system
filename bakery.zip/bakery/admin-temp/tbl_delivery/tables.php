<?php
$table="tbl_delivery";
$target_path = "uploads/";
$title="Delivery Agent";
?>