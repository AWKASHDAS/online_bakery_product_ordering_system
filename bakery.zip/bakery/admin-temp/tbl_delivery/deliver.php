<?php
	include("../db/connectionI.php");
	
	$up="UPDATE `tbl_mcart` SET `delivery_status`='delivered' WHERE `id`='$_REQUEST[id]'";
	$res=mysqli_query($con,$up);
	if($res)
					{
					echo '<script>alert("Succesfully Deliverd!")
							     window.location="view_orders.php";
								  </script>'; 
					
					}	
	
?>