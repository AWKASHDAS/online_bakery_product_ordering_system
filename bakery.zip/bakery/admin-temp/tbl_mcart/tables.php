<?php
$table="tbl_mcart";
$target_path = "uploads/";
$title="Recipe ";
?>