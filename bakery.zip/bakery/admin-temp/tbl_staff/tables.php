<?php
$table="tbl_staff";
$target_path = "uploads/";
$title="Add Staff ";
?>