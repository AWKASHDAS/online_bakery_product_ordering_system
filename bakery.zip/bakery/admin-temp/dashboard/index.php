
<?php
//session_start();
include('../header.php');
?>
<!--main content start-->
<section id="main-content">
	<section class="wrapper">
		<!-- //market-->
		<div class="market-updates">
		<?php 
		if($_SESSION['user']=="admin" || $_SESSION['user']=="staff")
		{
		?>
			<div class="col-md-3 market-update-gd">
			<a href='../tbl_category/select.php'>
				<div class="market-update-block clr-block-1">
					
					<div class="col-md-8 market-update-left">
					<h4>Category</h4>
						<h3></h3>
						<p></p>
					</div>
				  <div class="clearfix"> </div>
				</div>
			</a>
			</div>
			
			<div class="col-md-3 market-update-gd">
				<a href='../tbl_subcategory/select.php'>
				<div class="market-update-block clr-block-3">
					
					<div class="col-md-8 market-update-left">
						<h4>Sub Category</h4>
						<h3></h3>
						<p></p>
					</div>
				  <div class="clearfix"> </div>
				</div>
				</a>
			</div>
			
			
			
			<div class="col-md-3 market-update-gd">
				<a href='../tbl_customer/select.php'>
				<div class="market-update-block clr-block-3">
					
					<div class="col-md-8 market-update-left">
						<h4>Customer </h4>
						<h3></h3>
						<p></p>
					</div>
				  <div class="clearfix"> </div>
				</div>
				</a>
			</div>
		<?php
		}
		if($_SESSION['user']=="admin")
		{
		?>	
			
			<div class="col-md-3 market-update-gd">
			<a href='../tbl_staff/select.php'>
				<div class="market-update-block clr-block-1">
					
					<div class="col-md-8 market-update-left">
					<h4>Staff</h4>
						<h3></h3>
						<p></p>
					</div>
				  <div class="clearfix"> </div>
				</div>
			</a>
			</div>
		<?php
		}
		if($_SESSION['user']=="admin" || $_SESSION['user']=="staff")
		{
		?>
			
			<div class="col-md-3 market-update-gd">
			<br><br>
				<a href='../tbl_item/select.php'>
				<div class="market-update-block clr-block-3">
					
					<div class="col-md-8 market-update-left">
						<h4>Products</h4>
						<h3></h3>
						<p></p>
					</div>
				  <div class="clearfix"> </div>
				</div>
				</a>
			</div>
			
			<div class="col-md-3 market-update-gd">
		<br><br>
			<a href='../tbl_payment/select.php'>
				<div class="market-update-block clr-block-5">
					
					<div class="col-md-8 market-update-left">
					<h4>Payment Details</h4>
						<h3></h3>
						<p></p>
					</div>
				  <div class="clearfix"> </div>
				</div>
			</a>
			</div>
			
			<div class="col-md-3 market-update-gd">
		<br><br>
			<a href='../tbl_mpurchase/form.php'>
				<div class="market-update-block clr-block-3">
					
					<div class="col-md-8 market-update-left">
					<h4>Purchase</h4>
						<h3></h3>
						<p></p>
					</div>
				  <div class="clearfix"> </div>
				</div>
			</a>
			</div>
			
			
			<div class="col-md-3 market-update-gd">
		<br><br>
			<a href='../tbl_partner/form.php'>
				<div class="market-update-block clr-block-3">
					
					<div class="col-md-8 market-update-left">
					<h4>Delivery Agent</h4>
						<h3></h3>
						<p></p>
					</div>
				  <div class="clearfix"> </div>
				</div>
			</a>
			</div>
			
			<div class="col-md-3 market-update-gd">
		<br><br>
			<a href='../tbl_delivery/view_orders.php'>
				<div class="market-update-block clr-block-3">
					
					<div class="col-md-3 market-update-left">
					<h4>Orders</h4>
						<h3></h3>
						<p></p>
					</div>
				  <div class="clearfix"> </div>
				</div>
			</a>
			</div>
			
		
			
		<?php
		}
		?>
		
		<?php 
		if($_SESSION['user']=="agent"|| $_SESSION['user']=="staff" || $_SESSION['user']=="admin")
		{
		?>
		
		<?php
		}
		?>
		
		
			
			
                    
		   <div class="clearfix"> </div>
		</div>	

	<div class="clearfix"> </div>	
</section>




<?php

include("../footer.php");


?>