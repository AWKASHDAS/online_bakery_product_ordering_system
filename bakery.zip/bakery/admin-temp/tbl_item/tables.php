<?php
$table="tbl_item";
$target_path = "uploads/";
$title="Add Item";
?>