<?php

header('location:cust/home.php');
?>