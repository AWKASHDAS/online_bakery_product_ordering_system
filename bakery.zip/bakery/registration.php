<!DOCTYPE html>
<html>
<head>
<title>Registeration</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="home.css">
<style>

body
{font-family: "Times New Roman", Georgia, Serif;
background-repeat: no-repeat;
background-attachment: fixed;
font-size:20px;
background-size: cover;
background-image: url('images/pastries.jpg')
}
table
{
background-color: #800000;
opacity:0.9;
font-size:20px;
}
td,tr
{
padding:100px;
opacity:10;
color:white;
}
input[type=password]
{
width:100%;
height:40;
}
input[type=text]
{
width:100%;
height:40;
}
input[type=submit]
{
padding:5px;
background-color:white;
font-size:18px;
}
h1, h2, h3, h4, h5, h6 {
  font-family: "Playfair Display";
  letter-spacing: 5px;
}
.a{
	    width: 100%;
    height: 40px;
}
</style>
</head>
<body background="images/pastries.jpg">

<!-- Navbar (sit on top) -->
<div class="w3-top">
  <div class="w3-bar w3-white w3-padding w3-card" style="letter-spacing:4px;">
    <a href="#home" class="w3-bar-item w3-button">Bake shop</a>
    <!-- Right-sided navbar links. Hide them on small screens -->
    <div class="w3-right w3-hide-small">
      <a href="cust/home.php" class="w3-bar-item w3-button">Home</a>
      <a href="login.php" class="w3-bar-item w3-button">Sign in</a>
    </div>
  </div>
</div>


<!-- Page content -->
    <center>
    <table>
		<tr><td>
		<h1>Customer Registration</h1>
				<form action="cust_ins.php" method="post">
				  <p>Full name</p>
				  <input type="text" name="fname" class="form-control" required="required" />
				  <p>Phone</p>
				  <input type="text" name="phone" pattern="[7,8,9][0-9]{9}" maxlength="10" required class="form-control">
				  <p>House name, Apartment, Building</p>
				  <input type="text" name="hname" required class="form-control" >
          <p>Street name</p>
          <input type="text" name="street" required class="form-control" >
          <p>Area</p>
          <input type="text" name="area" required class="form-control" >
          <p>Landmark</p>
          <input type="text" name="landmark" required class="form-control" >
				  <p>District</p>
				  <select name="district"  class="a" required  >
               <option>-----SELECT------</option>
                 <option value="kasargod">Kasargod</option>
                <option value="kannur">Kannur</option>
                <option value="kozhikode">Kozhikode</option>
                <option value="wayanad">Wayanad</option>
                <option value="malapuram">Malapuram</option>
                <option value="palakkad">Palakkad</option>
                <option value="thrissur">Thrissur</option>
                <option value="ernakulam">Ernakulam</option>
                <option value="idukki">Idukki</option>
                <option value="kottayam">Kottayam</option>
                <option value="alappuzha">Alappuzha</option>
                <option value="pathanamthitta">Pathanamthitta</option>
                <option value="kollam">Kollam</option>
                <option value="thiruvananthapuram">Thiruvananthapuram</option>
                </select>
				  <p>Pincode</p>
				  <input type="text"  required name="pin" maxlength="6">
				  <p>Email</p>
				  <input type="email" required name="email" class="a">
				  <p>Set password</p>
			    <input type="password" required name="password1" minlength="8" id="pswd1">
          <p>Re-type password</p>
          <input type="password" name="password2" minlength="8" id="pswd2">
			<br><br>
<center><input type="submit" value="Sign up" name="submit"></center>
</form>

</td></tr>
</table>
</center>
<!-- <footer class="w3-display-container w3-white w3-content w3-wide" style="max-width:1600px;min-width:500px">
<h2>Contact Details</h2>
Phone: 5764853564<br>
Email: bakery@gmail.com
</footer> -->
    	 

</body>
</html>
