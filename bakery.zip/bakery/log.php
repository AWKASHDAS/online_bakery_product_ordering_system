<?php
include('connection.php');

if (isset($_POST['login']))
{	
$username=$_POST['username']; 
$password=$_POST['password']; 

	if($username=="admin@gmail.com" && $password=="admin")
	{
		$_SESSION['user']='admin';
		header("location:admin-temp/dashboard/index.php");
	}
	else
	{

		$sel="SELECT * FROM tbl_login WHERE email='$username' and password='$password'";
		echo $sel;
		$result = mysqli_query($con,$sel) or die(mysql_error());
		$row=mysqli_fetch_array($result);
		//echo $row['type'];
		
		if($row['type']=="customer")
		{	
			$query = "SELECT * FROM tbl_customer WHERE cust_email='$username' and cust_password='$password' and `cust_status`='1'";	 
			$data=mysqli_query($con,$query);
			$count=mysqli_num_rows($data);
			if($count==1)
			{
				$query1 = "SELECT * FROM tbl_customer WHERE cust_email='$username' and cust_password='$password' and `cust_status`='1'";	 
				$datas=mysqli_query($con,$query1);
				$cc=mysqli_fetch_array($datas);
				
				$_SESSION['user']='customer';
				$_SESSION['id']=$cc['id'];
				header("location:cust/shop1.php");
			}
			else
			{
				echo "Error : ".mysqli_error($con);
				header("location:login.php?st=fail");
			}
		}
		else
		{
			if($row['type']=="staff")
			{	
				$query = "SELECT * FROM tbl_staff WHERE staff_email='$username' and staff_password='$password' and staff_status='1'";	 
				echo $query;
				$data=mysqli_query($con,$query);
				$count=mysqli_num_rows($data);
				if($count==1)
				{
					$query1 = "SELECT * FROM tbl_staff WHERE staff_email='$username' and staff_password='$password' and staff_status='1'";
					//echo $query1;
					$datas=mysqli_query($con,$query1);
					$cc=mysqli_fetch_array($datas);
					//echo $cc['name'];
					
					$_SESSION['user']='staff';
					$_SESSION['sid']=$cc['id'];
					header("location:admin-temp/dashboard/index.php");
				}
				else
				{
					echo "Error : ".mysqli_error($con);
					header("location:login.php?st=fail");
				}
			}
			if($row['type']=="agent")
			{	
				$query = "SELECT * FROM tbl_partner WHERE par_email='$username' and par_password='$password' and par_status='1'";	 
				echo $query;
				$data=mysqli_query($con,$query);
				$count=mysqli_num_rows($data);
				if($count==1)
				{
					$query1 = "SELECT * FROM tbl_partner WHERE par_email='$username' and par_password='$password' and par_status='1'";
					//echo $query1;
					$datas=mysqli_query($con,$query1);
					$cc=mysqli_fetch_array($datas);
					echo $cc['name'];
					
					$_SESSION['user']='agent';
					$_SESSION['aid']=$cc['id'];
					header("location:admin-temp/dashboard/index.php");
				}
				else
				{
					echo "Error : ".mysqli_error($con);
					header("location:login.php?st=fail");
				}
			}
		}
	}
}
	
?>
 
 



