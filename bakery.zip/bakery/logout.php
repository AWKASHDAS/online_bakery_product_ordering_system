<?php
include 'connection.php';
session_unset();
$_SESSION["type"]="";
$_SESSION["username"]="";
       
header('Location: '."/bake_shop/login.php");
?>
