<?php 
	include 'connection.php';

	if(isset($_POST['submit'])){
		extract($_POST);

		$q="SELECT * FROM `tbl_login` WHERE `email`='$email'";
		$res=select($q);
		// print_r($res);
		if(sizeof($res)>0){
			
			alert('Username already taken!');
			//header('Location: '."registration.php");
		}
	else{
		 $qc="INSERT INTO tbl_customer VALUES (null,'$fname','$phone','$hname','$street','$landmark','$area','$district','$pin','$email','$password1','1')";
		 echo $qc;
         insert($qc);
		 
		 $uid=mysqli_insert_id($con);
         $qw="INSERT INTO tbl_login VALUES (null,'$uid','$email','$password1','customer')";
         insert($qw);
        
         alert('Login credentials successfuly created.....');
         header('Location: '."login.php");
	}
}

 ?>