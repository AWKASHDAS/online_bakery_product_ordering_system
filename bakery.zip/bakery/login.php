

<html>
<head>
<title>Login page</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="home.css">
<style>

body
{font-family: "Times New Roman", Georgia, Serif;
background-repeat: no-repeat;
background-attachment: fixed;
font-size:20px;
background-size: cover;
}
table
{
background-color: #800000;
opacity:0.9;
font-size:20px;
}
td,tr
{
padding:100px;
opacity:10;
color:white;
}
input[type=password]
{
width:100%;
height:40;
}
input[type=text]
{
width:100%;
height:40;
}
input[type=submit]
{
padding:5px;
background-color:white;
font-size:18px;
}
h1, h2, h3, h4, h5, h6 {
  font-family: "Playfair Display";
  letter-spacing: 5px;
}
</style>
</head>
<body background="images/pastries.jpg">

<!-- Navbar (sit on top) -->
<div class="w3-top">
  <div class="w3-bar w3-white w3-padding w3-card" style="letter-spacing:4px;">
    <a href="cust/home.php" class="w3-bar-item w3-button">Bake shop</a>
    <!-- Right-sided navbar links. Hide them on small screens -->
    <div class="w3-right w3-hide-small">
      <a href="cust/home.php" class="w3-bar-item w3-button">Home</a>
      <a href="registration.php" class="w3-bar-item w3-button">Register here</a>
    </div>
  </div>
</div>


<!-- Page content -->
    <center>
      <br>
      <br>
    <table>
    <tr><td>
    <form method="POST" action="log.php">
    <h1 align="center">Sign In</h1>
    Email:<br><br>
    <input type="text" name ="username" class="text" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'User Name';}" ><a href="#" class=" icon user"></a>
    <br><br>
    Password:<br><br>
    <input type="password" name = "password" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Password';}"><a href="#" class=" icon lock"></a>
    <br><br><center><input type="submit"  value="Login" name="login"> <a href="#" class=" icon arrow"></a>                                                                                                                                                                                                                                 </h4>
    </center><br>
    <a href="registration.php" >Don't have an account?</a>
    </form>
    </td></tr>
    </table>
    </center>		 

   <!-- <footer class="w3-display-container w3-white w3-content w3-wide" style="max-width:1600px;min-width:500px">
<h2>Contact Details</h2>
Phone: 0484-1232323 <br>
Email: bakery@bakeshop.com 
</footer>-->
  </body>
</html>
