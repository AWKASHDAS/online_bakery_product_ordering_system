-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 02, 2022 at 05:26 AM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `shop1`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_card`
--

CREATE TABLE IF NOT EXISTS `tbl_card` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `cust_id` int(5) NOT NULL,
  `card_name` varchar(20) NOT NULL,
  `expiry_date` varchar(5) NOT NULL,
  `card_num` varchar(16) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cust_id` (`cust_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE IF NOT EXISTS `tbl_category` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`id`, `cat_name`) VALUES
(1, 'Cakes'),
(3, 'cookies '),
(4, 'Macarons'),
(5, 'Donuts'),
(6, 'cupcakes');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_ccart`
--

CREATE TABLE IF NOT EXISTS `tbl_ccart` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `om_id` int(50) NOT NULL,
  `item_id` int(50) NOT NULL,
  `order_qty` int(50) NOT NULL,
  `price` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tbl_ccart`
--

INSERT INTO `tbl_ccart` (`id`, `om_id`, `item_id`, `order_qty`, `price`) VALUES
(1, 1, 5, 6, 0),
(3, 1, 4, 14, 550);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cpurchase`
--

CREATE TABLE IF NOT EXISTS `tbl_cpurchase` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `mpur_id` int(5) NOT NULL,
  `item_id` int(5) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `subcat_id` int(11) NOT NULL,
  `qty` int(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `mpur_id` (`mpur_id`),
  KEY `item_id` (`item_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `tbl_cpurchase`
--

INSERT INTO `tbl_cpurchase` (`id`, `mpur_id`, `item_id`, `cat_id`, `subcat_id`, `qty`) VALUES
(2, 1, 5, 0, 0, 3),
(3, 1, 3, 0, 0, 5),
(4, 1, 1, 0, 0, 3),
(5, 1, 1, 0, 0, 2),
(6, 1, 5, 0, 0, 1),
(7, 1, 5, 1, 5, 2);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cust_name` varchar(20) NOT NULL,
  `cust_phone` varchar(10) NOT NULL,
  `cust_house` varchar(20) NOT NULL,
  `cust_street` varchar(20) NOT NULL,
  `cust_landmark` varchar(20) NOT NULL,
  `cust_area` varchar(20) NOT NULL,
  `cust_district` varchar(20) NOT NULL,
  `cust_pin` varchar(6) NOT NULL,
  `cust_email` varchar(40) NOT NULL,
  `cust_password` varchar(50) NOT NULL,
  `cust_status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `cust_phone` (`cust_phone`,`cust_email`),
  UNIQUE KEY `cust_email` (`cust_email`),
  UNIQUE KEY `cust_phone_2` (`cust_phone`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`id`, `cust_name`, `cust_phone`, `cust_house`, `cust_street`, `cust_landmark`, `cust_area`, `cust_district`, `cust_pin`, `cust_email`, `cust_password`, `cust_status`) VALUES
(1, 'Ann Liya', '8606249705', 'Kaniampuram House', 'Ponnarimangalam', 'Opposite to SBI bank', 'Mulavukad', 'ernakulam', '682504', 'liyakaniampuram2002@gmail.com', 'liya123', 1),
(2, 'ANTONY MATHEW', '9895209122', 'kan house', 'ponnarin', 'opp sbi', 'mulavu', 'ernakulam', '682504', 'antonymath@gmail.com', 'kani@1234', 1),
(3, 'mathew', '9897564553', 'kanasd asd', 'asda', 'zxcadasd', 'kja', 'ernakulam', '687543', 'antonymkj.psn@gmail.com', 'kani@1234', 1),
(4, 'Alfred js', '7355616258', 'd villat', 'lakef', 'palarivattomf', 'palarivattomf', 'ernakulam', '682025', 'alfrefdj@gmail.com', '123', 1),
(7, 'Alfred js', '7357616258', 'd villat', 'lakef', 'palarivattomf', 'palarivattomf', 'ernakulam', '682025', 'alhfrefdj@gmail.com', '123', 0),
(8, 'Jimmy', '9865234512', 'jims villa', 'Myl', 'Pta', 'Pta', 'pathanamthitta', '682025', 'jim@gmail.com', '123', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_item`
--

CREATE TABLE IF NOT EXISTS `tbl_item` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `cat_id` int(11) NOT NULL,
  `scat_id` int(5) NOT NULL,
  `item_name` varchar(20) NOT NULL,
  `item_des` varchar(255) NOT NULL,
  `item_price` int(11) NOT NULL,
  `item_stock` int(3) NOT NULL,
  `item_img` tinytext NOT NULL,
  `status` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `scat_id` (`scat_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `tbl_item`
--

INSERT INTO `tbl_item` (`id`, `cat_id`, `scat_id`, `item_name`, `item_des`, `item_price`, `item_stock`, `item_img`, `status`) VALUES
(1, 1, 1, '1kg ', 'Chocolate cake or chocolate gateau is a cake flavored with melted chocolate, cocoa powder, or both.', 500, 10, 'chocolate_cake.jpg', 'stock'),
(3, 1, 1, '2kg ', 'Rich decadent chocolate sponge cake layers filled with a smooth chocolate buttercream and topped with fresh berries', 1000, 8, '2022-10-29-09-01-20chocolate_cake.jpg', 'stock'),
(4, 3, 4, 'Box of 6', 'Butter cookies, also known as Danish biscuits, are cookies originating in Denmark consisting of butter, flour, and sugar. Originating in Denmark, they are similar to shortbread cookies. ', 550, 7, '2022-10-29-09-26-02butter_cookie.jpg', 'stock'),
(5, 1, 5, '1kg Vanila cake', 'The heavenly taste of this Choco Truffle Cake will even leave the hardest-to-please chocolate addicts tranquil in every sense. Prepared with three layers of relishing chocolate cream filled in between the soft stacks of chocolate cake, and adorned with be', 549, 15, '2022-10-29-09-22-18vanilla_cake.jpg', 'stock'),
(8, 3, 4, 'Box of 12', 'Butter cookies, also known as Danish biscuits, are cookies originating in Denmark consisting of butter, flour, and sugar. Originating in Denmark, they are similar to shortbread cookies. ', 450, 0, '2022-10-29-09-28-51butter_cookie.jpg', 'stock');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_login`
--

CREATE TABLE IF NOT EXISTS `tbl_login` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(20) NOT NULL,
  `email` varchar(40) NOT NULL,
  `password` varchar(10) NOT NULL,
  `type` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `tbl_login`
--

INSERT INTO `tbl_login` (`id`, `user_id`, `email`, `password`, `type`) VALUES
(1, '', 'admin@gmail.com', 'admin', 'administrator'),
(2, '', 'sammueljames@gmail.com', 'james123', 'staff'),
(3, '', 'shreyamenon123@gmail.com', '123shreya', 'delivery partner'),
(4, '', 'liyakaniampuram2002@gmail.com', 'liya123', 'customer'),
(5, '', 'antonymath@gmail.com', 'kani@1234', 'customer'),
(6, '', 'antonymkj.psn@gmail.com', 'kani@1234', 'customer'),
(9, '', 'paul@gmail.com', '123', 'staff'),
(10, '', 'mike@gmail.com', '123', 'agent'),
(11, '', 'gokul@gmail.com', '123456', 'staff'),
(12, '', 'alfred@gmail.com', '123', 'customer'),
(13, '', 'alfredj@gmail.com', '123', 'customer'),
(14, '', 'alfrefdj@gmail.com', '123', 'customer'),
(15, '', 'ravi@gmail.com', '123', 'staff'),
(16, '8', 'jim@gmail.com', '123', 'customer'),
(17, '23', 'tessy@gmail.com', '123', 'staff');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_mcart`
--

CREATE TABLE IF NOT EXISTS `tbl_mcart` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `c_id` int(50) NOT NULL,
  `date` date NOT NULL,
  `status` varchar(10) NOT NULL,
  `delivery_status` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_mcart`
--

INSERT INTO `tbl_mcart` (`id`, `c_id`, `date`, `status`, `delivery_status`) VALUES
(1, 3, '2022-10-30', 'Completed', 'delivered');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_mpurchase`
--

CREATE TABLE IF NOT EXISTS `tbl_mpurchase` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `ven_id` int(5) NOT NULL,
  `tot_amount` varchar(10) NOT NULL,
  `pur_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ven_id` (`ven_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_mpurchase`
--

INSERT INTO `tbl_mpurchase` (`id`, `ven_id`, `tot_amount`, `pur_date`) VALUES
(1, 7, '5000', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_partner`
--

CREATE TABLE IF NOT EXISTS `tbl_partner` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `staff_id` int(5) NOT NULL,
  `par_name` varchar(20) NOT NULL,
  `par_no` varchar(10) NOT NULL,
  `par_email` varchar(35) NOT NULL,
  `par_password` varchar(30) NOT NULL,
  `par_aadhar` varchar(12) NOT NULL,
  `par_status` varchar(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `par_no` (`par_no`),
  UNIQUE KEY `par_email` (`par_email`),
  KEY `staff_id` (`staff_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `tbl_partner`
--

INSERT INTO `tbl_partner` (`id`, `staff_id`, `par_name`, `par_no`, `par_email`, `par_password`, `par_aadhar`, `par_status`) VALUES
(1, 1, 'mike', '1234567890', 'mike@gmail.com', '123', '134567899876', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_payment`
--

CREATE TABLE IF NOT EXISTS `tbl_payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `u_id` varchar(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `rate` varchar(20) NOT NULL,
  `card_type` varchar(50) NOT NULL,
  `card_name` varchar(50) NOT NULL,
  `card_no` varchar(50) NOT NULL,
  `card_year` varchar(50) NOT NULL,
  `card_month` varchar(50) NOT NULL,
  `cvv` varchar(50) NOT NULL,
  `time` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tbl_payment`
--

INSERT INTO `tbl_payment` (`id`, `u_id`, `order_id`, `rate`, `card_type`, `card_name`, `card_no`, `card_year`, `card_month`, `cvv`, `time`, `status`) VALUES
(1, '', 3, '1650', 'debit', 'Roshan', '1234567898765444', '2023', '10', '123', '2022-10-29 07:22:19', 'Completed'),
(2, '2', 3, '1650', 'debit', 'Roshan', '1234567898765444', '2023', '10', '123', '2022-10-29 07:23:23', 'Completed'),
(3, '2', 4, '1099', 'debit', 'alfred', '1234567890123456', '2023', '9', '123', '2022-10-29 10:17:32', 'Completed'),
(4, '3', 1, '7700', 'debit', 'Roshan', '1234567890123453', '2023', '10', '123', '2022-10-30 11:59:21', 'Completed');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_staff`
--

CREATE TABLE IF NOT EXISTS `tbl_staff` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `staff_name` varchar(20) NOT NULL,
  `staff_phone` varchar(10) NOT NULL,
  `staff_address` varchar(100) NOT NULL,
  `staff_email` varchar(35) NOT NULL,
  `staff_password` varchar(20) NOT NULL,
  `staff_aadhar` varchar(12) NOT NULL,
  `staff_status` varchar(10) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `staff_email` (`staff_email`),
  UNIQUE KEY `staff_phone` (`staff_phone`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `tbl_staff`
--

INSERT INTO `tbl_staff` (`id`, `staff_name`, `staff_phone`, `staff_address`, `staff_email`, `staff_password`, `staff_aadhar`, `staff_status`) VALUES
(1, 'Paul', '7558921345', 'kochi', 'paul@gmail.com', '123', '123456789098', '0'),
(13, 'gokul', '9865896598', 'hjghjg', 'gokul@gmail.com', '123456', '123456789098', '0'),
(22, 'Ravi', '7508621345', 'kochi', 'ravi@gmail.com', '123', '123456789098', '1'),
(23, 'Tessy', '9857431209', 'kochi', 'tessy@gmail.com', '123', '672345678346', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_subcategory`
--

CREATE TABLE IF NOT EXISTS `tbl_subcategory` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `cat_id` int(5) NOT NULL,
  `scat_name` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cat_id` (`cat_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `tbl_subcategory`
--

INSERT INTO `tbl_subcategory` (`id`, `cat_id`, `scat_name`) VALUES
(1, 1, 'Chocolate cake'),
(4, 3, 'Butter Cookies'),
(5, 1, 'Vanilla Cake'),
(7, 4, 'Classic Glazed Donut'),
(8, 5, 'Chocolate Glazed Don'),
(9, 6, 'Raspberry cupcakes');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_vendor`
--

CREATE TABLE IF NOT EXISTS `tbl_vendor` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `staff_id` int(5) NOT NULL,
  `ven_name` varchar(20) NOT NULL,
  `ven_no` varchar(10) NOT NULL,
  `ven_email` varchar(35) NOT NULL,
  `ven_status` varchar(10) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ven_email` (`ven_email`),
  UNIQUE KEY `ven_no` (`ven_no`),
  KEY `staff_id` (`staff_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `tbl_vendor`
--

INSERT INTO `tbl_vendor` (`id`, `staff_id`, `ven_name`, `ven_no`, `ven_email`, `ven_status`) VALUES
(7, 1, 'Bake Shop', '8965326589', 'bake@gmail.com', 'Active');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_card`
--
ALTER TABLE `tbl_card`
  ADD CONSTRAINT `tbl_card_ibfk_1` FOREIGN KEY (`cust_id`) REFERENCES `tbl_customer` (`id`);

--
-- Constraints for table `tbl_cpurchase`
--
ALTER TABLE `tbl_cpurchase`
  ADD CONSTRAINT `tbl_cpurchase_ibfk_1` FOREIGN KEY (`mpur_id`) REFERENCES `tbl_mpurchase` (`id`),
  ADD CONSTRAINT `tbl_cpurchase_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `tbl_item` (`id`);

--
-- Constraints for table `tbl_item`
--
ALTER TABLE `tbl_item`
  ADD CONSTRAINT `tbl_item_ibfk_1` FOREIGN KEY (`scat_id`) REFERENCES `tbl_subcategory` (`id`);

--
-- Constraints for table `tbl_mpurchase`
--
ALTER TABLE `tbl_mpurchase`
  ADD CONSTRAINT `tbl_mpurchase_ibfk_1` FOREIGN KEY (`ven_id`) REFERENCES `tbl_vendor` (`id`);

--
-- Constraints for table `tbl_partner`
--
ALTER TABLE `tbl_partner`
  ADD CONSTRAINT `tbl_partner_ibfk_1` FOREIGN KEY (`staff_id`) REFERENCES `tbl_staff` (`id`);

--
-- Constraints for table `tbl_subcategory`
--
ALTER TABLE `tbl_subcategory`
  ADD CONSTRAINT `tbl_subcategory_ibfk_1` FOREIGN KEY (`cat_id`) REFERENCES `tbl_category` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
