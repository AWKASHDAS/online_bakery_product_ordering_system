<?php 
//session_start();
//error_reporting(0);
$con=mysqli_connect('localhost','root','','shop1',3306);
?>