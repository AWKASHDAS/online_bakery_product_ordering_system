<html>
<head>
<title>Shop</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="shop.css">
<link rel="stylesheet" href="shop1.css">
<link rel="stylesheet" href="shop2.css">
<link rel="stylesheet" href="shop3.css">
<style>

h1, h2, h3, h4, h5, h6 {
  font-family: "Playfair Display";
  letter-spacing: 5px;
}
i{
	margin-left: 10px;
}
}
</style>
</head>
<body class="w3-content" style="max-width:1200px">

<!-- Sidebar/menu -->
<?php
include("sidebar.php");
?>

<!-- Top menu on small screens -->
<header class="w3-bar w3-top w3-hide-large w3-black w3-xlarge">
  <div class="w3-bar-item w3-padding-24 w3-wide">LOGO</div>
  <a href="javascript:void(0)" class="w3-bar-item w3-button w3-padding-24 w3-right" onclick="w3_open()"><i class="fa fa-bars"></i></a>
</header>

<!-- Overlay effect when opening sidebar on small screens -->
<div class="w3-overlay w3-hide-large" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

<!-- !PAGE CONTENT! -->
<div class="w3-main" style="margin-left:250px">
<!-- Push down content on small screens -->
  <div class="w3-hide-large" style="margin-top:83px"></div>
  
  <!-- Top header -->
<?php
include("header.php");
include('../connection.php');
$res2=mysqli_query($con,"SELECT * FROM `tbl_category` WHERE `id`='$_REQUEST[id]'");
//echo "SELECT * FROM `tbl_category` WHERE `id`='$_REQUEST[id]'";
$row2=mysqli_fetch_array($res2);
?>


  <!-- Product grid -->
  <!-- !PAGE CONTENT! -->
<div class="w3-main w3-content w3-padding " style="max-width:1200px">
<h2 class="w3-wide w3-center"><?php echo $row2['cat_name']; ?></h2>
<!-- First Photo Grid-->
<div class="w3-row-padding w3-padding-16 w3-center" id="food">
<?php

$res=mysqli_query($con,"SELECT * FROM `tbl_item` WHERE `cat_id`='$_REQUEST[catid]'");
//echo "SELECT * FROM `tbl_item` WHERE `cat_id`='$_REQUEST[catid]'";
while($row=mysqli_fetch_array($res))
{
	$res1=mysqli_query($con,"SELECT * FROM `tbl_subcategory` WHERE `cat_id`='$row[cat_id]'");
	//echo "SELECT * FROM `tbl_subcategory` WHERE `cat_id`='$row[cat_id]'";
	$row1=mysqli_fetch_array($res1);
	//echo $row['item_name'];
?>

  
  <div class="w3-col l4 s6">
	<div class="w3-container">
       <div class="w3-display-container">
        <img src="../admin-temp/tbl_item/uploads/<?php echo $row['item_img']; ?>" style="width: 250px; height: 366px;">
        <div class="w3-display-middle w3-display-hover">
        <a href="item_single.php?itemid=<?php echo $row['id']; ?>"><button class="w3-button w3-black">Buy now <i class="fa-solid fa-cart-shopping"></i></button></a>
        </div>
       </div>
        <p><?php echo $row['item_name']; ?><br><b>Rs.<?php echo $row['item_price']; ?></b></p>
     </div>
	 </div>

<?php
}
?>
</div>


</div>

  
  <!-- End page content -->
</div>

<!-- Newsletter Modal -->
<div id="newsletter" class="w3-modal">
  <div class="w3-modal-content w3-animate-zoom" style="padding:32px">
    <div class="w3-container w3-white w3-center">
      <h2 class="w3-wide">CONTACT</h2>
      <p>Have any queries or suggestions? Reach out to us! Your satisfaction is our priority.</p>
      <P>Contact us by phone 0484-1232323 or email bakery@bakeshop.com</p>
      <button type="button" class="w3-button w3-padding-large w3-red w3-margin-bottom" onclick="document.getElementById('newsletter').style.display='none'" class="fa fa-remove w3-right w3-button w3-transparent w3-xxlarge">Close</button>
    </div>
  </div>
</div>

<script>
// Accordion 
function myAccFunc() {
  var x = document.getElementById("demoAcc");
  if (x.className.indexOf("w3-show") == -1) {
    x.className += " w3-show";
  } else {
    x.className = x.className.replace(" w3-show", "");
  }
}

// Click on the "Jeans" link on page load to open the accordion for demo purposes
document.getElementById("myBtn").click();


// Open and close sidebar
function w3_open() {
  document.getElementById("mySidebar").style.display = "block";
  document.getElementById("myOverlay").style.display = "block";
}
 
function w3_close() {
  document.getElementById("mySidebar").style.display = "none";
  document.getElementById("myOverlay").style.display = "none";
}
</script>

</body>
</html>
