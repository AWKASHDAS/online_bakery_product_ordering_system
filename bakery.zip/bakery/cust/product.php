<?php

include("../connection.php");
$a=$_SESSION['qty'];
$c=$_SESSION['id'];
//echo $c;

mysqli_query($con,"UPDATE tbl_item SET item_stock=item_stock-$a WHERE id='$c'");
//echo "UPDATE tbl_item SET item_stock=item_stock-$a WHERE id='$c'";
header("location:cart.php");
?>