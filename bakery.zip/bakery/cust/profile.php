<?php
session_start();
error_reporting(0);
?>
<html>
<head>
<title>Chocolate Cake</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="shop.css">
<link rel="stylesheet" href="shop1.css">
<link rel="stylesheet" href="shop2.css">
<link rel="stylesheet" href="shop3.css">
<link rel="stylesheet" href="product.css">
<link rel="stylesheet" href="form.css">
<style>

h1, h2, h3, h4, h5, h6 {
  font-family: "Playfair Display";
  letter-spacing: 5px;
}
table {
  border-collapse: collapse;
  width: 1060px;
}

th, td {
  padding: 8px;
  text-align: left;
  border-bottom: 1px solid #ddd;
}
</style>
</head>

<body class="w3-content" style="max-width:1200px">

<!-- Sidebar/menu -->
<?php
include("sidebar.php");
?>

<!-- Top menu on small screens -->
<header class="w3-bar w3-top w3-hide-large w3-black w3-xlarge">
  <div class="w3-bar-item w3-padding-24 w3-wide">LOGO</div>
  <a href="javascript:void(0)" class="w3-bar-item w3-button w3-padding-24 w3-right" onclick="w3_open()"><i class="fa fa-bars"></i></a>
</header>

<!-- Overlay effect when opening sidebar on small screens -->
<div class="w3-overlay w3-hide-large" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

<!-- !PAGE CONTENT! -->
<div class="w3-main" style="margin-left:250px">
<!-- Push down content on small screens -->
  <div class="w3-hide-large" style="margin-top:83px"></div>
 
<br><br> 
  <!-- Top header -->
<?php
include("header.php");
?>

<div class="col-md-12" style="padding:20px;">
                        <h3>Customer Profile</h3><br>
						<?php 
							session_start();
							include ("connection.php");
						
							$sel2="SELECT * FROM `tbl_customer` WHERE `id`='$_SESSION[id]'";
							$res2=mysqli_query($con,$sel2);
							$row=mysqli_fetch_array($res2);
							?>
									
								
                           
						  
						  
				<form  method="POST" action="update_data.php?id=<?php echo $_SESSION['id'] ?>">
					<div class="field padding-bottom--24">
					  <label >Name</label>
					  <input type="text" name="cust_name" class="input" value="<?php echo $row['cust_name']; ?>"   readonly>
					</div>
					
					<div class="field padding-bottom--24">
					  <div class="grid--50-50">
						<label for="password">Phone</label>
					  </div>
					  <input  name="cust_phone" type="text" placeholder="Card Holder" value="<?php echo $row['cust_phone']; ?>" class="form-control input-md" required>
					</div>
					
					<div class="field padding-bottom--24">
					  <div class="grid--50-50">
						<label for="password">House</label>
					  </div>
					  <input  name="cust_house" type="text" placeholder="Card Number" value="<?php echo $row['cust_house']; ?>" class="form-control input-md" required>
					</div>
					
					<div class="field padding-bottom--24">
					  <div class="grid--50-50">
						<label for="password">Street</label>
					  </div>
					  <input  name="cust_street" type="text" placeholder="Card Number" value="<?php echo $row['cust_street']; ?>" class="form-control input-md" required>
					</div>
					
					<div class="field padding-bottom--24">
					  <div class="grid--50-50">
						<label for="password">Landmark</label>
					  </div>
					  <input  name="cust_landmark" type="text" placeholder="Card Number" value="<?php echo $row['cust_landmark']; ?>" class="form-control input-md" required>
					</div>
					
					<div class="field padding-bottom--24">
					  <div class="grid--50-50">
						<label for="password">Area</label>
					  </div>
					  <input  name="cust_area" type="text" placeholder="Card Number" value="<?php echo $row['cust_area']; ?>" class="form-control input-md" required>
					</div>
					
					<div class="field padding-bottom--24">
					  <div class="grid--50-50">
						<label for="password">District</label>
					  </div>
					  <input  name="cust_district" type="text" placeholder="Card Number" value="<?php echo $row['cust_district']; ?>" class="form-control input-md" required>
					</div>
					
					<div class="field padding-bottom--24">
					  <div class="grid--50-50">
						<label for="password">Pincode</label>
					  </div>
					  <input  name="cust_pin" type="text" placeholder="Card Number" value="<?php echo $row['cust_pin']; ?>" class="form-control input-md" required>
					</div>
					
					<div class="field padding-bottom--24">
					  <div class="grid--50-50">
						<label for="password">Email</label>
					  </div>
					  <input  name="cust_email" type="text" placeholder="Card Number" value="<?php echo $row['cust_email']; ?>" class="form-control input-md" required>
					
					 <input  name="cust_emailold" type="hidden"  value="<?php echo $row['cust_email']; ?>" class="form-control input-md" required>
					
					</div>
					
					<div class="field padding-bottom--24">
					  <div class="grid--50-50">
						<label for="password">Password</label>
					  </div>
					  <input  name="cust_password" type="password" placeholder="Card Number" value="<?php echo $row['cust_password']; ?>" class="form-control input-md" required>
					<br><br>
					<input  name="submit" type="submit"value='update' class="btn btn-success" />
					
					</div>
					
				  </form>
						</div>
  


<!-- Newsletter Modal -->
<div id="newsletter" class="w3-modal">
  <div class="w3-modal-content w3-animate-zoom" style="padding:32px">
    <div class="w3-container w3-white w3-center">
      <h2 class="w3-wide">CONTACT</h2>
      <p>Have any queries or suggestions? Reach out to us! Your satisfaction is our priority.</p>
      <P>Contact us by phone 0484-1232323 or email bakery@bakeshop.com</p>
      <button type="button" class="w3-button w3-padding-large w3-red w3-margin-bottom" onclick="document.getElementById('newsletter').style.display='none'" class="fa fa-remove w3-right w3-button w3-transparent w3-xxlarge">Close</button>
    </div>
  </div>
</div>

<script>
// Accordion 
function myAccFunc() {
  var x = document.getElementById("demoAcc");
  if (x.className.indexOf("w3-show") == -1) {
    x.className += " w3-show";
  } else {
    x.className = x.className.replace(" w3-show", "");
  }
}

// Click on the "Jeans" link on page load to open the accordion for demo purposes
document.getElementById("myBtn").click();


// Open and close sidebar
function w3_open() {
  document.getElementById("mySidebar").style.display = "block";
  document.getElementById("myOverlay").style.display = "block";
}
 
function w3_close() {
  document.getElementById("mySidebar").style.display = "none";
  document.getElementById("myOverlay").style.display = "none";
}
</script>

</body>
</html>
