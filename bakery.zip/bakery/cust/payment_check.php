<?php 
	session_start();
	error_reporting(0);
	include ("connection.php");
?>
<html>
<head>
<title>Payment</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="shop.css">
<link rel="stylesheet" href="shop1.css">
<link rel="stylesheet" href="shop2.css">
<link rel="stylesheet" href="shop3.css">
<link rel="stylesheet" href="form.css">
<style>

h1, h2, h3, h4, h5, h6 {
  font-family: "Playfair Display";
  letter-spacing: 5px;
}



</style>
</head>
<body class="w3-content" style="max-width:1200px">

<!-- Sidebar/menu -->
<nav class=" w3-bar-block w3-white w3-collapse w3-top" style="z-index:3;width:250px" id="mySidebar">
  <div class="w3-container w3-display-container w3-padding-16">
    <i onclick="w3_close()" class="fa fa-remove w3-hide-large w3-button w3-display-topright"></i>
    <h3 class="w3-wide"><a href="shop1.php" class="w3-bar-item w3-button"><b>Bake Shop</b></a></h3>
  </div>

</nav>

<!-- Top menu on small screens -->
<header class="w3-bar w3-top w3-hide-large w3-black w3-xlarge">
  <div class="w3-bar-item w3-padding-24 w3-wide"></div>
  <a href="javascript:void(0)" class="w3-bar-item w3-button w3-padding-24 w3-right" onclick="w3_open()"><i class="fa fa-bars"></i></a>
</header>

<!-- Overlay effect when opening sidebar on small screens -->
<div class="w3-overlay w3-hide-large" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

<!-- !PAGE CONTENT! -->
<div class="w3-main" style="margin-left:250px">
<!-- Push down content on small screens -->
  <div class="w3-hide-large" style="margin-top:83px"></div>
  <br><br>
  <!-- Top header -->
<?php
include("header.php");

$amount=$_REQUEST['amount'];
	
?>

  <!-- Product grid -->
  <!-- !PAGE CONTENT! -->
  <br><br><br>
<div class="w3-main w3-content w3-padding " style="max-width:1200px">
<h2 class="w3-wide w3-center" style="margin-left: -123px;">Payment</h2>

<div class="container">
   <div class="formbg-outer" style="margin-left: -164px;">
	  <div class="formbg">
		<div class="formbg-inner padding-horizontal--48">
		  <form  method="POST">
			<div class="field padding-bottom--24">
			  <label >Payable Amount</label>
			  <input type="text" name="amt" class="input" value="<?php echo $amount; ?>"   readonly>
			</div>
			
			<div class="field padding-bottom--24">
			  <div class="grid--50-50">
				<label for="password">Card Holder</label>
			  </div>
			  <input  name="holder" type="text" placeholder="Card Holder" class="form-control input-md" required>
			</div>
			
			<div class="field padding-bottom--24">
			  <div class="grid--50-50">
				<label for="password">Card Number</label>
			  </div>
			  <input  name="num" type="text" placeholder="Card Number" pattern="[0-9]{16}" class="form-control input-md" required>
			</div>
			
			<div class="field padding-bottom--24">
			  <div class="grid--50-50">
				<label for="password">Card Type</label>
			  </div>
			    <select name="card" class="form-control input-md">
				  <option value="">-- Select --</option>
				  <option value="debit">Debit </option>
				  <option value="credit">Credit</option>
				</select> 
			</div>
			
			<div class="field padding-bottom--24">
			  <div class="grid--50-50">
				<label for="password">Expire Month</label>
			  </div>
			    <select name="mm" class="form-control input-md">
				  <option value="">-- Select --</option>
				  <option value="1">01 </option>
				  <option value="2">02</option>
				  <option value="3">03</option>
				  <option value="4">04</option>
				  <option value="5">05</option>
				  <option value="6">06</option>
				  <option value="7">07</option>
				  <option value="8">08</option>
				  <option value="9">09</option>
				  <option value="10">10</option>
				  <option value="11">11</option>
				  <option value="12">12</option>
				</select>
			</div>
			
			<div class="field padding-bottom--24">
			  <div class="grid--50-50">
				<label for="password">Expire Year</label>
			  </div>
			    <select name="yy" class="form-control input-md">
				  <option value="">-- Select --</option>
				  <option value="2022">2022 </option>
				  <option value="2023">2023 </option>
				  <option value="2024">2024 </option>
				  <option value="2025">2025</option>
				  <option value="2026">2026</option>
				</select> 
			</div>
			
			<div class="field padding-bottom--24">
			  <div class="grid--50-50">
				<label for="password">CVV</label>
			  </div>
			  <input  name="cvv" type="password" placeholder="CVV" pattern="[0-9]{3}" class="form-control input-md" required>
			</div>
			<div class="field padding-bottom--24">
			  <input type="submit" name="submit" value="Submit">
			</div>
		  </form>
		  
		  
<?php
if(isset($_POST['submit']))
{
	date_default_timezone_set('Asia/Kolkata');
    $currentTime = date( 'Y-m-d h:i:s');
	$card=$_POST['card'];
	$holder=$_POST['holder'];
	$num=$_POST['num'];
	$mm=$_POST['mm'];
	$yy=$_POST['yy'];
	$cvv=$_POST['cvv'];
	$rate=$_POST['rate'];
    
    $ins="INSERT INTO tbl_payment(u_id,order_id, rate,card_type, card_name, card_no, card_year, card_month, time, status) values('$_SESSION[id]','$_REQUEST[omid]','$_REQUEST[amount]','$card','$holder','$num','$yy','$mm','$currentTime','Completed')";
	//echo $ins;
	$res=mysqli_query($con,$ins);
	
	
		$match2= "UPDATE tbl_mcart SET status='Completed',delivery_status='pending' WHERE c_id='$_SESSION[id]' and status='cart'"; 
		
		$_SESSION['amt']=$_POST['amt'];
		$qry2 = mysqli_query($con,$match2);
	
    if($res & $qry2)
		{
			//echo $ins;
			//echo "<script>
		///alert('insert successfully')
			//window.location='view_order.php';
			
			echo "<script >alert(\"Item Order Placed\");
				window.location.replace(\"../cust/view_order.php\");</script>";

			
		} 
	
}
?>
		  
		</div>
	  </div>
	</div>
</div>

  
  <!-- End page content -->
</div>

<!-- Newsletter Modal -->

</div>



</body>
</html>
