<?php 
//error_reporting(0);
session_start();
include("connection.php");

if(isset($_POST['submit']))
{
	echo "ssss";
	
	
	$date=date('Y-m-d');
//echo $date;

		$match2= "UPDATE tbl_mcart SET status='Completed' WHERE c_id='$_SESSION[id]' and status='cart'"; 
	  $_SESSION['amt']=$_POST['amt'];
	   if($qry2 = mysqli_query($con,$match2))
	   {
	   
	   
				if($_POST['pay'] == "Pay By Cash")
				{
					
			echo "<script >alert(\"Item Order Places\");
				window.location.replace(\"../cust/shop1.php\");</script>";
				}
				else{
				  echo "<script >alert(\"Item Order Places\");
				window.location.replace(\"first.php\");</script>"; 
//header("location:First.php");				
				} 
				//header("location:");
	   }
	   else
	   {
		   header("location:../login/index.php?st=tbl_paymento");
	   }
}
	
?>    