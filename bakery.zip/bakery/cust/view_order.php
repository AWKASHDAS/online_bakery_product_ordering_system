<?php
session_start();
error_reporting(0);
?>
<html>
<head>
<title>Bake Shop</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="shop.css">
<link rel="stylesheet" href="shop1.css">
<link rel="stylesheet" href="shop2.css">
<link rel="stylesheet" href="shop3.css">
<link rel="stylesheet" href="product.css">
<style>

h1, h2, h3, h4, h5, h6 {
  font-family: "Playfair Display";
  letter-spacing: 5px;
}
table {
  border-collapse: collapse;
  width: 1060px;
}

th, td {
  padding: 8px;
  text-align: left;
  border-bottom: 1px solid #ddd;
}
</style>
</head>

<body class="w3-content" style="max-width:1200px">

<!-- Sidebar/menu -->
<?php
include("sidebar.php");
?>

<!-- Top menu on small screens -->
<header class="w3-bar w3-top w3-hide-large w3-black w3-xlarge">
  <div class="w3-bar-item w3-padding-24 w3-wide"></div>
  <a href="javascript:void(0)" class="w3-bar-item w3-button w3-padding-24 w3-right" onclick="w3_open()"><i class="fa fa-bars"></i></a>
</header>

<!-- Overlay effect when opening sidebar on small screens -->
<div class="w3-overlay w3-hide-large" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

<!-- !PAGE CONTENT! -->
<div class="w3-main" style="margin-left:250px">
<!-- Push down content on small screens -->
  <div class="w3-hide-large" style="margin-top:83px"></div>
  
  <!-- Top header -->
<?php
include("header.php");
?>

<div class="col-md-12">
                        <h3>Order Details</h3><br>
						<?php 
							session_start();
							include ("connection.php");
							
						?>
						
                        <table class="table table-striped table-bordered table-hover">
                           
                                <tr>
									<th>No</th>
														
                                    <th>Order id </th>
									
                                    <th>Date </th>
									
                                    <th>Item Name </th>
									
									<th>Quantity</th>
								
								    <th>Price</th>
									
									<th>Order Status</th>
                                </tr>
								
                            <?php
									$sel2="SELECT * FROM `tbl_ccart` LEFT JOIN tbl_mcart on tbl_ccart.om_id = tbl_mcart.id where status='Completed' and tbl_mcart.c_id='$_SESSION[id]'";
									//echo $sel2;
									$res2=mysqli_query($con,$sel2);
									$i=1;
									while($row2=mysqli_fetch_array($res2))
									{
										$res3=mysqli_query($con,"SELECT * FROM `tbl_item` WHERE `id`='$row2[item_id]'");
										$row3=mysqli_fetch_array($res3);
										
										$res4=mysqli_query($con,"SELECT * FROM `tbl_subcategory` WHERE id='$row3[scat_id]'");
										//echo "SELECT * FROM `tbl_subcategory` WHERE id='$row3[scat_id]'";
										$row4=mysqli_fetch_array($res4);
										//echo $row4['scat_name'];
 
							?>
									
								
                           
                                <tr>
									<td><?php echo $i; ?></td>
                                    
                                   <td><?php echo $row2['om_id']?></td>
								   
                                   <td><?php echo $row2['date']?></td>
									
									<td><?php echo $row3['item_name']?></td>
                                    
								   <td ><?php echo $row2['order_qty']?></td>
									
								    <td><?php echo $row2['price']?></td>
								 
									<td><?php echo $row2['delivery_status']?></td>
									
                                </tr>
                           
                      
							<?php
								$i++;
								}
								
								?>
						  </table>
						</div>
  


<!-- Newsletter Modal -->
<div id="newsletter" class="w3-modal">
  <div class="w3-modal-content w3-animate-zoom" style="padding:32px">
    <div class="w3-container w3-white w3-center">
      <h2 class="w3-wide">CONTACT</h2>
      <p>Have any queries or suggestions? Reach out to us! Your satisfaction is our priority.</p>
      <P>Contact us by phone 0484-1232323 or email bakery@bakeshop.com</p>
      <button type="button" class="w3-button w3-padding-large w3-red w3-margin-bottom" onclick="document.getElementById('newsletter').style.display='none'" class="fa fa-remove w3-right w3-button w3-transparent w3-xxlarge">Close</button>
    </div>
  </div>
</div>

<script>
// Accordion 
function myAccFunc() {
  var x = document.getElementById("demoAcc");
  if (x.className.indexOf("w3-show") == -1) {
    x.className += " w3-show";
  } else {
    x.className = x.className.replace(" w3-show", "");
  }
}

// Click on the "Jeans" link on page load to open the accordion for demo purposes
document.getElementById("myBtn").click();


// Open and close sidebar
function w3_open() {
  document.getElementById("mySidebar").style.display = "block";
  document.getElementById("myOverlay").style.display = "block";
}
 
function w3_close() {
  document.getElementById("mySidebar").style.display = "none";
  document.getElementById("myOverlay").style.display = "none";
}
</script>

</body>
</html>
