<nav class="w3-sidebar w3-bar-block w3-white w3-collapse w3-top" style="z-index:3;width:250px" id="mySidebar">
  <div class="w3-container w3-display-container w3-padding-16">
    <i onclick="w3_close()" class="fa fa-remove w3-hide-large w3-button w3-display-topright"></i>
    <h3 class="w3-wide"><a href="shop1.php" class="w3-bar-item w3-button"><b>Bake Shop</b></a></h3>
  </div>
  <div class="w3-padding-64 w3-large w3-text-grey">
  <?php
	include('connection.php');
	$res=mysqli_query($con,"SELECT * FROM `tbl_category` ");
	while($row=mysqli_fetch_array($res))
	{
  ?>
    <a href="items.php?catid=<?php echo $row['id']; ?> " class="w3-button w3-block w3-white w3-left-align" >
      <?php echo $row['cat_name']; ?> 
    </a>
   <?php
	}
	?>

  </div>

  </div>
    <a href="shop1.php" class="w3-bar-item w3-button">Home</a>
  <a href="javascript:void(0)" class="w3-bar-item w3-button w3-padding" onclick="document.getElementById('newsletter').style.display='block'">Contact</a> 
</div>
</nav>