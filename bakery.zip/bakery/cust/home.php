<!DOCTYPE html>
<html>
<head>
<title>Home page</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="home.css">
<style>
body {
background: #800000;
font-family: "Times New Roman", Georgia, Serif;
font-size:20px;}
h1, h2, h3, h4, h5, h6 {
  font-family: "Playfair Display";
  letter-spacing: 5px;
}
</style>
</head>
<body>

<!-- Navbar (sit on top) -->
<div class="w3-top">
  <div class="w3-bar w3-white w3-padding w3-card" style="letter-spacing:4px;">
    <a href="#home" class="w3-bar-item w3-button">Bake Shop</a>
    <!-- Right-sided navbar links. Hide them on small screens -->
    <div class="w3-right w3-hide-small">
      <a href="../login.php" class="w3-bar-item w3-button">Sign In</a>
    <a href="shop1.php" class="w3-bar-item w3-button">Shop</a>
    </div>
  </div>
</div>

<!-- Header -->
<header class="w3-display-container w3-content w3-wide" style="max-width:1600px;min-width:500px" id="home">
  <img class="w3-image" src="../images/pastries.jpg" alt="Pastries" width="1600" height="800">
  <div class="w3-display-middle w3-padding-large w3-border w3-white w3-wide w3-text-black w3-center">
   <h1 class="w3-hide-medium w3-hide-small w3-xxxlarge">BAKE SHOP</h1>
    <h5 class="w3-hide-large" style="white-space:nowrap">BAKE SHOP</h5>
    <h3 class="w3-hide-medium w3-hide-small">baked goodness</h3>
  </div>
  
  
</header>

<!-- Page content -->
<div class="w3-content w3-text-white" style="max-width:1100px">

  <!-- About Section -->
  <div class="w3-row w3-padding-64" id="about">
    <div class="w3-col m6 w3-padding-large w3-hide-small">
     <img src="../images/cake.jpg" class="w3-round w3-image w3-opacity-1" alt="Table Setting" width="600" height="750">
    </div>

    <div class="w3-col m6 w3-padding-large">
      <h1 class="w3-center">About us</h1><br>
      <h5 class="w3-center">All things baked to perfection</h5>
      <p class="w3-large">The Bake shop has one promise to keep, to deliver its customers with the best and freshest of baked goodies. From rich decadant cakes to crispy sweet macarons, we have all that your heart could desire. </p>
      <p class="w3-large w3-hide-medium">Only the highest quality of ingredients go into our recipes. Not to mention, our most loved recipes have been perfected over the last 5 years. Our team consists of dedicated and passionate pastry chefs to bring gourmet worthy food to your doorstep. Order now! </p>
    </div>
  </div>
  
  <hr>
  
  <!-- Menu Section -->
  <div class="w3-row w3-padding-64" id="menu">
    <div class="w3-col l6 w3-padding-large">
      <h1 class="w3-center">Our Highlights</h1><br>
      <h4>Assorted Macarons</h4>
      <p class="w3-text-grey">An assortment of chocolate, strawberry and caramel macarons</p><br>
    
      <h4>Honey Almond Layered Cake</h4>
      <p class="w3-text-grey">Layered in between sheets of almond sponge cake is a rich honey infused buttercream</p><br>
    
      <h4>Assorted Donuts</h4>
      <p class="w3-text-grey">A box of 5 donuts consisting of sugar-glazed, chocolate glazed, dark chocolate-filled, jelly-filled, and pink glazed donuts.</p><br>
    
      <h4>Butter Cookies</h4>
      <p class="w3-text-grey">Made with fresh European butter, our butter cookies are the best tea time snack</p><br>
    
      <h4>Classic Chocolate Cake</h4>
      <p class="w3-text-grey">Rich moist cake with chocolate buttercream, topped with fresh strawberries.</p>    
    </div>
    
    <div class="w3-col l6 w3-padding-large">
     <!-- <img src="/w3images/tablesetting.jpg" class="w3-round w3-image w3-opacity-min" alt="Menu" style="width:100%">-->
      <div class="mySlides w3-display-container w3-center">
    <img src="../images/macarons.jpg" style="width:50% height:75%">
    <div class="w3-display-bottommiddle w3-container w3-text-white w3-padding-32 w3-hide-small">
      
    </div>
  </div>
  <div class="mySlides w3-display-container w3-center">
    <img src="../images/honey_almond_cake.jpg" style="width:40%">
    <div class="w3-display-bottommiddle w3-container w3-text-white w3-padding-32 w3-hide-small">
     
    </div>
  </div>
  <div class="mySlides w3-display-container w3-center">
    <img src="../images/donuts.jpg" style="width:50% height:75%">
    <div class="w3-display-bottommiddle w3-container w3-text-white w3-padding-32 w3-hide-small">
      
    </div>
    
  </div>
  <div class="mySlides w3-display-container w3-center">
    <img src="../images/butter_cookie.jpg" style="width:50% height:75%">
    <div class="w3-display-bottommiddle w3-container w3-text-white w3-padding-32 w3-hide-small">
      
    </div>
    
  </div>


    </div>
  </div>

  <hr>

  <!-- Contact Section -->
  <div class="w3-container w3-padding-64" id="contact">
    <h1>Contact</h1><br>
    <p>Have any queries or suggestions? Reach out to us! Your satisfaction is our priority.</p>
    <p>Contact us by phone 0484-1232323 or email bakery@bakeshop.com</p>
  </div>
  
<!-- End page content -->
</div>

<!-- Footer 
<footer class="w3-center w3-light-grey w3-padding-32">
  <p>Powered by <a href="https://www.w3schools.com/w3css/default.asp" title="W3.CSS" target="_blank" class="w3-hover-text-green">w3.css</a></p>
</footer>-->

</body>
</html>
