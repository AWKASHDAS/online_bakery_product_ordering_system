<style>
a{
	text-decoration: none;
}
</style>

<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <header class="w3-container w3-xlarge">
   <p class="w3-right">
   <?php
   session_start();
   
	error_reporting(0);
   //echo $_SESSION['user'];
   if($_SESSION['user']=='customer')
   {
   ?>
	  <a href="cart.php"><i class='fa fa-shopping-cart'>Cart</i></a>
	  <a href="view_order.php"><i class='fa fa-shopping-cart'>View Orders</i></a>
      <a href="profile.php"><i class="fa fa-user" >Profile</i></a>
	  <a href="logout.php"><i class="fa fa-sign-out">Sign out</i></a>
   <?php
   }else
   {
	?>
      <a href="home.php">Home</a>
	  <a href="../login.php">Sign In</a>
   <?php
   }
   ?>
   </p>
  </header>