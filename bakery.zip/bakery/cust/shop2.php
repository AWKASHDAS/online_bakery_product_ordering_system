<html>
<head>
<title>Shop</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="shop.css">
<link rel="stylesheet" href="shop1.css">
<link rel="stylesheet" href="shop2.css">
<link rel="stylesheet" href="shop3.css">
<style>

h1, h2, h3, h4, h5, h6 {
  font-family: "Playfair Display";
  letter-spacing: 5px;
}
</style>
</head>
<body class="w3-content" style="max-width:1200px">

<!-- Sidebar/menu -->
<?php
include("sidebar.php");
?>

<!-- Top menu on small screens -->
<header class="w3-bar w3-top w3-hide-large w3-black w3-xlarge">
  <div class="w3-bar-item w3-padding-24 w3-wide">LOGO</div>
  <a href="javascript:void(0)" class="w3-bar-item w3-button w3-padding-24 w3-right" onclick="w3_open()"><i class="fa fa-bars"></i></a>
</header>

<!-- Overlay effect when opening sidebar on small screens -->
<div class="w3-overlay w3-hide-large" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

<!-- !PAGE CONTENT! -->
<div class="w3-main" style="margin-left:250px">

  <!-- Push down content on small screens -->
  <div class="w3-hide-large" style="margin-top:83px"></div>
  
  <!-- Top header -->
<?php
include("header.php");
?>


<section class="w3l-products-2">
	<div class="wrapper">
		<div class="product">
		<div class="w3l-products-2">

		
			<div class="main">
				<div class="grid grid-column-2">
				
				  <?php
					$sql="SELECT * FROM tbl_item WHERE status='stock'";
				  echo $sql;
					$result = mysqli_query($con,$sql);
					while($row = mysqli_fetch_array($result))
					{
				  ?>
					<div class="column1">
						<a href=""><img src="<?php echo "uploads/".$row['item_img']; ?>" class="img-responsive" /></a>
						<a href="#price2">
							<p class="product-para"><?php echo "RS ".$row['item_price']; ?></p>
						</a>
						
						<a href="">
							<p class="heading"><?php echo $row['item_name']; ?></p>
						</a>
						<a href="checkout.php" class="add-cart"><span class="fa fa-shopping-basket"></span></a>
						<a href="sales.php?id=<?php echo $row['id']; ?>" class="buy">Buy Now</a>
					</div>
					<?php
					}
					?>
					
				</div>
				
			</div>
		</div>
	</div>
	</div>
</section>

  
  

  
  
  <!-- End page content -->
</div>

<!-- Newsletter Modal -->
<div id="newsletter" class="w3-modal">
  <div class="w3-modal-content w3-animate-zoom" style="padding:32px">
    <div class="w3-container w3-white w3-center">
      <h2 class="w3-wide">CONTACT</h2>
      <p>Have any queries or suggestions? Reach out to us! Your satisfaction is our priority.</p>
      <P>Contact us by phone 0484-1232323 or email bakery@bakeshop.com</p>
      <button type="button" class="w3-button w3-padding-large w3-red w3-margin-bottom" onclick="document.getElementById('newsletter').style.display='none'" class="fa fa-remove w3-right w3-button w3-transparent w3-xxlarge">Close</button>
    </div>
  </div>
</div>

<script>
// Accordion 
function myAccFunc() {
  var x = document.getElementById("demoAcc");
  if (x.className.indexOf("w3-show") == -1) {
    x.className += " w3-show";
  } else {
    x.className = x.className.replace(" w3-show", "");
  }
}

// Click on the "Jeans" link on page load to open the accordion for demo purposes
document.getElementById("myBtn").click();


// Open and close sidebar
function w3_open() {
  document.getElementById("mySidebar").style.display = "block";
  document.getElementById("myOverlay").style.display = "block";
}
 
function w3_close() {
  document.getElementById("mySidebar").style.display = "none";
  document.getElementById("myOverlay").style.display = "none";
}
</script>

</body>
</html>
