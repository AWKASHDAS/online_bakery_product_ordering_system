<html>
<head>
<title>Cakes</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="shop.css">
<link rel="stylesheet" href="shop1.css">
<link rel="stylesheet" href="shop2.css">
<link rel="stylesheet" href="shop3.css">
<style>

h1, h2, h3, h4, h5, h6 {
  font-family: "Playfair Display";
  letter-spacing: 5px;
}
i{
	margin-left: 10px;
}
}
</style>
</head>
<body class="w3-content" style="max-width:1200px">

<!-- Sidebar/menu -->
<?php
include("sidebar.php");
?>
<!-- Top menu on small screens -->
<header class="w3-bar w3-top w3-hide-large w3-black w3-xlarge">
  <div class="w3-bar-item w3-padding-24 w3-wide">LOGO</div>
  <a href="javascript:void(0)" class="w3-bar-item w3-button w3-padding-24 w3-right" onclick="w3_open()"><i class="fa fa-bars"></i></a>
</header>

<!-- Overlay effect when opening sidebar on small screens -->
<div class="w3-overlay w3-hide-large" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

<!-- !PAGE CONTENT! -->
<div class="w3-main" style="margin-left:250px">
<!-- Push down content on small screens -->
  <div class="w3-hide-large" style="margin-top:83px"></div>
  
  <!-- Top header -->
<?php
include("header.php");
?>


  <!-- Product grid -->
  <!-- !PAGE CONTENT! -->
<div class="w3-main w3-content w3-padding " style="max-width:1200px">
<h2 class="w3-wide w3-center" >Cakes</h2>
<!-- First Photo Grid-->

<?php

if(isset($_REQUEST['id']))
				{
				$query1="SELECT * FROM tbl_item WHERE id='$_REQUEST[id]'";
				$result1= mysqli_query($con,$query1) or die(mysqli_error());
					$row1 = mysqli_fetch_array($result1);
				}


if(isset($_POST['submit']))
{

//error_reporting(0);
session_start();
//$date=date("Y-m-d");

if ($_SESSION['id']=='')
{
echo "<script >alert(\"Please Signin first\");
window.location.replace(\"../login/index.php\");</script>";
	

}

else
{
$query6="SELECT * FROM tbl_mcart WHERE c_id='$_SESSION[id]' and status='cart' ";

//echo $query6;
$result6=mysqli_query($con,$query6);


$row6 = mysqli_fetch_array( $result6);
$count=mysqli_num_rows($result6);
	
	//echo $query6;
	//echo"count".$count;

if($count==1)

{
	$query7="INSERT INTO tbl_ccart(item_id,om_id,order_qty,price) VALUES('$_REQUEST[id]','$row6[id]','$_POST[quantity]','$row1[item_price]')";
 mysqli_query($con,$query7);
 

 mysqli_query($con,"UPDATE tbl_item SET item_stock=item_stock-$_POST[quantity] WHERE id='$_REQUEST[id]'");
 
	//header("location:product.php");
}
else
{

$ddate=date('Y-m-d');
	
$query8="INSERT INTO tbl_mcart(c_id,date,status) VALUES('$_SESSION[id]','$ddate','cart')";
//echo $query8;

if($result8=mysqli_query($con,$query8))
{
	$oid=mysqli_insert_id($con);
	$query9="INSERT INTO tbl_ccart(item_id,om_id,order_qty,price) 
VALUES('$_REQUEST[id]','$oid','$_POST[quantity]','$row1[rate]')";
 $result9=mysqli_query($con,$query9);
	
	echo "<script>
	//window.location.replace(\"../product/product.php\");</script>";
}
else
{
	echo "Error : ".mysqli_error($con);
}

}


}


}






?>
 <?php
			$result = mysqli_query($con,"SELECT * FROM tbl_item WHERE id='$_REQUEST[id]'");
 		$row=mysqli_fetch_array($result);
		
		$resultc = mysqli_query($con,"SELECT * FROM tbl_category WHERE id='$row[cat_id]'");
 		$rowc=mysqli_fetch_array($resultc);
		
			?>
<section class="w3l-ecommerce-single">
    <div class="ecommerce-page">
        <div class="wrapper">
            <div class="ecommerce-cart-two">
                <div class="cart-image">
                    <a href="" class="column-img" id="zoomIn">
                        <figure>
                            <img src="../admin-temp/tbl_item/uploads/<?php echo $row['item_img']; ?>" alt="product" class="img-responsive" />
                        </figure>
                    </a>

                </div>
                <div class="cart-details">
                    <h4> <?php echo $row['item_name']; ?></h4>
                    <div class="ratings">
                        <ul class="star">
                            <li><a href="#star"><span class="fa fa-star" aria-hidden="true"></span></a>
                            </li>
                            <li><a href="#star"><span class="fa fa-star" aria-hidden="true"></span></a>
                            </li>
                            <li><a href="#star"><span class="fa fa-star-half-o" aria-hidden="true"></span></a>
                            </li>
                            <li><a href="#star"><span class="fa fa-star-o" aria-hidden="true"></span></a>
                            </li>
                            <li><a href="#star"><span class="fa fa-star-o" aria-hidden="true"></span></a>
                            </li>
                        </ul>
                    </div>
                    <ul>
                        <li><h6><?php echo "Rate :" . $row['item_price']; ?></h6></li>
                        <li><?php echo "Category :" . $rowc['cat_name']; ?></li>
                    </ul>
                    <p class="single"><?php echo $row['item_des']; ?></p>
                    <div class="sec-grid-1">
                        <label>Quantity:</label>
                        <div class="disply-cont">
                         <form action="" method="post">
                            <input type="number" name="quantity" value="1" min="1" max="<?php echo $row['item_stock'];?>" />
                            <input type="submit" name="submit" value="Buy Now" class="buy"/>
                            </form>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</section>