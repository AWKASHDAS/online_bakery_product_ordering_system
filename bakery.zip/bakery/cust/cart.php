<?php
session_start();
error_reporting(0);
?>
<html>
<head>
<title>Chocolate Cake</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="shop.css">
<link rel="stylesheet" href="shop1.css">
<link rel="stylesheet" href="shop2.css">
<link rel="stylesheet" href="shop3.css">
<link rel="stylesheet" href="product.css">
<style>

h1, h2, h3, h4, h5, h6 {
  font-family: "Playfair Display";
  letter-spacing: 5px;
}
table {
  border-collapse: collapse;
  width: 1060px;
}

th, td {
  padding: 8px;
  text-align: left;
  border-bottom: 1px solid #ddd;
}
</style>
</head>

<body class="w3-content" style="max-width:1200px">

<!-- Sidebar/menu -->
<?php
include("sidebar.php");
?>

<!-- Top menu on small screens -->
<header class="w3-bar w3-top w3-hide-large w3-black w3-xlarge">
  <div class="w3-bar-item w3-padding-24 w3-wide">LOGO</div>
  <a href="javascript:void(0)" class="w3-bar-item w3-button w3-padding-24 w3-right" onclick="w3_open()"><i class="fa fa-bars"></i></a>
</header>

<!-- Overlay effect when opening sidebar on small screens -->
<div class="w3-overlay w3-hide-large" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

<!-- !PAGE CONTENT! -->
<div class="w3-main" style="margin-left:250px">
<!-- Push down content on small screens -->
  <div class="w3-hide-large" style="margin-top:83px"></div>
  
  <!-- Top header -->
<?php
include("header.php");
?>

<?php
if(isset($_REQUEST['did']))
{
$query6="DELETE FROM tbl_ccart WHERE id='$_REQUEST[did]'";

if(mysqli_query($con,$query6))
{
	
 mysqli_query($con,"UPDATE tbl_item SET item_stock=item_stock+$_REQUEST[quantity] WHERE id='$_REQUEST[item_id]'");
 
header("location:cart.php");	
}
else
{
	echo "Error : ".mysqli_error($con);
}
}?>


<main class="container">

<section class="w3l-products-12-main">
	<div class="product-inner">
		<h3 class="heading">Shopping cart</h3>
		<div class="wrapper">
			<div class="checkout-right">
				<div class="table-responsive">
					<table class="table" border="1">
						<thead>
							<tr>
								<th>Product</th>
								<th>Product Name</th>
								<th>Quantity</th>
								<th>Price</th>
								<th>Remove</th>
							</tr>
						</thead>
						<tbody>
							
					 
             <?php
		

$query = "SELECT * FROM tbl_mcart WHERE c_id='$_SESSION[id]' and status='cart'"; 
$result=mysqli_query($con,$query);

while($row = mysqli_fetch_array($result))
{
//echo $row['id'];

      $query2 = "SELECT * FROM tbl_ccart WHERE om_id='$row[id]'";
	  //echo $query2;
      $result2=mysqli_query($con,$query2);
   
	       while($row2 = mysqli_fetch_array( $result2 )) {
			  // echo $row2['id'];
				   
			   $query3 = "SELECT * FROM `tbl_item` WHERE `id`='$row2[item_id]'";
			   //echo $query3;
               $result3=mysqli_query($con,$query3);
	              while($row3 = mysqli_fetch_array($result3)) {
	                  //echo $row3['item_img'];

?>	
							<tr class="rem1">
								<td class="invert-image">
									<a href="">
										<img src="../admin-temp/tbl_item/uploads/<?php echo $row3['item_img']; ?>" alt=" " class="img-responsive" style="width: 100px; height: 100px;">
									</a>
								</td>
								
								<td class="invert product-name"><a href="product.php">
										<?php echo $row3['item_name']; ?></a>

								</td>
								<td class="invert">
									<?php echo $row2['order_qty']; ?>
								</td>
								<td class="invert price">
								<?php $amount=$row2['price']*$row2['order_qty'];echo $row2['price']." X ".$row2['order_qty']." = ₹ ".$amount;?> </td>
								<td class="">
									<a class="proceed read-more-1 btn" href="cart.php?did=<?php echo $row2['id'];?>&quantity=<?php echo $row2['order_qty'];?>&item_id=<?php echo $row2['item_id'];?>" class="close1"><i class="fa fa-remove" style="font-size:30px;color:red"></i></a>
								</td>
							</tr>
							
	<?php
				  }
}}
				  ?>						
<?php 
				 $query4 = "SELECT * FROM tbl_mcart WHERE c_id='$_SESSION[id]' and status='cart'"; 
$result4=mysqli_query($con,$query4);

while($row4 = mysqli_fetch_array($result4))
{

//echo $row4['id'];
$cid=$row4['id'];

      $query5 = "select SUM(order_qty*price),COUNT(item_id)FROM tbl_ccart WHERE om_id='$row4[id]'";
	 //echo $query5;
      $result5=mysqli_query($con,$query5);
	  $row5=mysqli_fetch_array($result5);

}
			  
           ?>
							<tr>
								<td></td>
								<td></td>
								<td class="invert price total-price">
									<h5 class="price"><?php echo ":  ". $row5['COUNT(item_id)']; ?></h5>
								
									<h6 class="totla-pay">Total Payable :</h6>
								</td>
								<td class="invert price total-price">
								
									<h6 class="totla-pay"><?php echo ": ₹ ". $row5['SUM(order_qty*price)']; ?></h6>
								</td>
							</tr>

						</tbody>
					</table>
				</div>
			</div>
			<br><br>
			<div class="checkout-left">
				<div class="address_form_hny">
					<div class="checkout-right-basket">
						<a href="shop1.php" class="shop-btn">Continue Shopping
						</a>
						<a href="payment_check.php?amount=<?php echo $row5['SUM(order_qty*price)']; ?> &omid=<?php echo $cid;?>" class="cart-btn">Checkout
						</a>
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
</section> 
  
</main>

<!-- Newsletter Modal -->
<div id="newsletter" class="w3-modal">
  <div class="w3-modal-content w3-animate-zoom" style="padding:32px">
    <div class="w3-container w3-white w3-center">
      <h2 class="w3-wide">CONTACT</h2>
      <p>Have any queries or suggestions? Reach out to us! Your satisfaction is our priority.</p>
      <P>Contact us by phone 0484-1232323 or email bakery@bakeshop.com</p>
      <button type="button" class="w3-button w3-padding-large w3-red w3-margin-bottom" onclick="document.getElementById('newsletter').style.display='none'" class="fa fa-remove w3-right w3-button w3-transparent w3-xxlarge">Close</button>
    </div>
  </div>
</div>

<script>
// Accordion 
function myAccFunc() {
  var x = document.getElementById("demoAcc");
  if (x.className.indexOf("w3-show") == -1) {
    x.className += " w3-show";
  } else {
    x.className = x.className.replace(" w3-show", "");
  }
}

// Click on the "Jeans" link on page load to open the accordion for demo purposes
document.getElementById("myBtn").click();


// Open and close sidebar
function w3_open() {
  document.getElementById("mySidebar").style.display = "block";
  document.getElementById("myOverlay").style.display = "block";
}
 
function w3_close() {
  document.getElementById("mySidebar").style.display = "none";
  document.getElementById("myOverlay").style.display = "none";
}
</script>

</body>
</html>
