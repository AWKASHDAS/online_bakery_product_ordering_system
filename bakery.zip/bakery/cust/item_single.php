
<html>
<head>
<title>Shop</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="shop.css">
<link rel="stylesheet" href="shop1.css">
<link rel="stylesheet" href="shop2.css">
<link rel="stylesheet" href="shop3.css">
<link rel="stylesheet" href="product.css">
<style>

h1, h2, h3, h4, h5, h6 {
  font-family: "Playfair Display";
  letter-spacing: 5px;
}
</style>
</head>
<body class="w3-content" style="max-width:1200px">

<!-- Sidebar/menu -->
<?php
//include('../connection.php');
include("sidebar.php");
$res=mysqli_query($con,"SELECT * FROM tbl_item WHERE id='$_REQUEST[itemid]'");
$row=mysqli_fetch_array($res);
echo $row['item_stock'];

$res1=mysqli_query($con,"SELECT * FROM `tbl_category` WHERE `id`='$row[cat_id]'");
$row1=mysqli_fetch_array($res1);

$res2=mysqli_query($con,"SELECT * FROM `tbl_subcategory` WHERE `id`='$row[scat_id]'");
$row2=mysqli_fetch_array($res2);

?>

<?php
	if(isset($_REQUEST['itemid']))
		{
		$query1="SELECT * FROM tbl_item WHERE id='$_REQUEST[itemid]'";
		$result1= mysqli_query($con,$query1) or die('connection failed');
		$row1 = mysqli_fetch_array($result1);
		}


		if(isset($_POST['submit']))
		{
			error_reporting(0);
			session_start();
			//$date=date("Y-m-d");

			if ($_SESSION['id']=='')
			{
				echo "<script >alert(\"Please Signin first\");
				window.location.replace(\"../login.php\");</script>";
			}
			else
			{
				$query6="SELECT * FROM tbl_mcart WHERE c_id='$_SESSION[id]' and status='cart' ";

				//echo $query6;
				$result6=mysqli_query($con,$query6);
				$row6 = mysqli_fetch_array( $result6);
				$count=mysqli_num_rows($result6);
				
				//echo $query6;
				//echo"count".$count;

				if($count==1)
				{
					$query7="INSERT INTO tbl_ccart(item_id,om_id,order_qty,price) VALUES('$_REQUEST[itemid]','$row6[id]','$_POST[quantity]','$row1[item_price]')";
					mysqli_query($con,$query7);
				 

					mysqli_query($con,"UPDATE tbl_item SET item_stock=item_stock-$_POST[quantity] WHERE id='$_REQUEST[itemid]'");
				 
					header("location:cart.php");
				}
				else
				{
				$ddate=date('Y-m-d');
					
				$query8="INSERT INTO tbl_mcart(c_id,date,status) VALUES('$_SESSION[id]','$ddate','cart')";
				//echo $query8;

					if($result8=mysqli_query($con,$query8))
					{
						$oid=mysqli_insert_id($con);
						$query9="INSERT INTO tbl_ccart(item_id,om_id,order_qty,price) 
					VALUES('$_REQUEST[itemid]','$oid','$_POST[quantity]','$row1[item_price]')";
					 $result9=mysqli_query($con,$query9);
						mysqli_query($con,"UPDATE tbl_item SET item_stock=item_stock-$_POST[quantity] WHERE id='$_REQUEST[itemid]'");
				 
						echo "<script>
						window.location.replace(\"/cust/cart.php\");</script>";
					}
					else
					{
						echo "Error : ".mysqli_error($con);
					}
				}
			}
}

?>

<!-- Top menu on small screens -->
<header class="w3-bar w3-top w3-hide-large w3-black w3-xlarge">
  <div class="w3-bar-item w3-padding-24 w3-wide">LOGO</div>
  <a href="javascript:void(0)" class="w3-bar-item w3-button w3-padding-24 w3-right" onclick="w3_open()"><i class="fa fa-bars"></i></a>
</header>

<!-- Overlay effect when opening sidebar on small screens -->
<div class="w3-overlay w3-hide-large" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

<!-- !PAGE CONTENT! -->
<div class="w3-main" style="margin-left:250px">
<!-- Push down content on small screens -->
  <div class="w3-hide-large" style="margin-top:83px"></div>
  
  <!-- Top header -->
<?php
include("header.php");
?>


  <main class="container">
 
  <!-- Left Column / Headphones Image -->
  <div class="left-column">
    <img data-image="red" class="active" src="../admin-temp/tbl_item/uploads/<?php echo $row['item_img']; ?>" alt="" style="width:70%">
  </div>
 
 
  <!-- Right Column -->
  <div class="right-column">
 
    <!-- Product Description -->
    <div class="product-description">
      <span><?php echo $row1['cat_name']; ?></span>
      <h1><?php echo $row['item_name']; ?></h1>
      <p><?php echo $row['item_des']; ?></p>
    </div>
 
    <!-- Product Configuration -->
    <div class="product-configuration">
 
      <!-- Cable Configuration -->
      <div class="cable-config">
 
        <div class="cable-choose">
          <form method="POST">
		  <div>
			Quantity: <input type="number" name="quantity" value="1" min="1" max="<?php echo $row['item_stock'];?>"  > <br><br>
			
		  </div>
		  
        </div>
 
      </div>
    </div>
 
    <!-- Product Pricing -->
    <div class="product-price">
      <span>₹<?php echo $row['item_price']; ?></span>
	  <?php
	  if($row['item_stock']>0)
	  {
	  ?>
      <input type="submit" name="submit" value="Add to cart" class="cart-btn">
	  <?php
	  }
	  else{
		  echo"No Stock Available";
	  }
	  ?>
	  
	  </form>
    </div>
  </div>
</main>

<!-- Newsletter Modal -->
<div id="newsletter" class="w3-modal">
  <div class="w3-modal-content w3-animate-zoom" style="padding:32px">
    <div class="w3-container w3-white w3-center">
      <h2 class="w3-wide">CONTACT</h2>
      <p>Have any queries or suggestions? Reach out to us! Your satisfaction is our priority.</p>
      <P>Contact us by phone 0484-1232323 or email bakery@bakeshop.com</p>
      <button type="button" class="w3-button w3-padding-large w3-red w3-margin-bottom" onclick="document.getElementById('newsletter').style.display='none'" class="fa fa-remove w3-right w3-button w3-transparent w3-xxlarge">Close</button>
    </div>
  </div>
</div>

<script>
// Accordion 
function myAccFunc() {
  var x = document.getElementById("demoAcc");
  if (x.className.indexOf("w3-show") == -1) {
    x.className += " w3-show";
  } else {
    x.className = x.className.replace(" w3-show", "");
  }
}

// Click on the "Jeans" link on page load to open the accordion for demo purposes
document.getElementById("myBtn").click();


// Open and close sidebar
function w3_open() {
  document.getElementById("mySidebar").style.display = "block";
  document.getElementById("myOverlay").style.display = "block";
}
 
function w3_close() {
  document.getElementById("mySidebar").style.display = "none";
  document.getElementById("myOverlay").style.display = "none";
}
</script>

</body>
</html>
